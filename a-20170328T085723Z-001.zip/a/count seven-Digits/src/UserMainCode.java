public class UserMainCode {
 
            public static int digits(int s1) {
                        int rem = 0, count = 0;
                        while (s1 > 0) {
                                    rem = s1 % 10;
                                    if (rem == 7)
                                                count++;
                                    s1 = s1 / 10;
                        }
                        return count;
            }
}