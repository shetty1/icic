import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashSet;


public class User {
    public static int findPrefix(String s[]) {
        LinkedHashSet<String> l1 = new LinkedHashSet<String>();
        ArrayList<String> al = new ArrayList<String>();
        int c = 0;
        for (int i = 0; i < s.length; i++)
            l1.add(s[i]);
Iterator<String> it = l1.iterator();
while (it.hasNext()) {
            al.add(it.next());
}
for (int i = 0; i < al.size(); i++) {
            String s2 = al.get(i);
            for (int j = 0; j < al.size(); j++) {
                        String s3 = al.get(j);
                        if ((i != j) && (s3.length() > s2.length())) {
                                    String s4 = s3.substring(0, s2.length());
                                    if (s2.equals(s4))
                                                c++;
                        }
            }
}
return c;
}

}
