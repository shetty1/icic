import java.util.HashSet;
import java.util.Scanner;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int size = sc.nextInt();
		String input[] = new String[size];
		for (int i = 0; i < size; i++) {
		input[i] = sc.next();
		}
		HashSet<String> hs = new HashSet<String>();
		for (int i = 0; i < size; i++) {
		hs.add(input[i]);
		}
		size = hs.size();
		int i = 0;

		int count = 0;
		for (i = 0; i < size; i++) {
		for (int j = 0; j < size; j++) {
		if (input[i].equals(input[j]) == false) {
		if (input[j].startsWith(input[i])) {

		count++;
		}
		}
		}
		}
		System.out.println(count);
	}

}
