public class UserMainCode {
            public static boolean scores(int a[]) {
                        boolean b = false;
                        for (int i = 0; i < a.length - 1; i++) {
                                    if (a[i] == 100 && a[i + 1] == 100) {
                                                b = true;
                                                break;
                                    } else {
                                                b = false;
                                    }
                        }
                        return b;
            }
}
