public class UserMainCode {
            public static int phoneValidate(String s1) {
                        if (s1.matches("[0-9-]{12}")) {
                                    return 1;
                        } else {
                                    return 2;
                        }
            }
}