import java.util.Scanner;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n;
Scanner sc=new Scanner(System.in);
n=sc.nextInt();
int []a=new int[n];
for(int i=0;i<a.length;i++)
{
	a[i]=sc.nextInt();
}
int b=UserMainCode.getLargestSpan(a, n);
System.out.println(b);

	}

}
