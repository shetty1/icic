public class UserMainCode {
 
            public static int getLargestSpan(int[] a, int n) {
                        int gap = 0, max = 0;
                        for (int i = 0; i < n; i++) {
                                    for (int j = i + 1; j < n; j++) {
                                                if (a[i] == a[j]) {
                                                            gap = j;
                                                }
                                    }
                                    if (gap - 1 > max)
                                                max = gap - i;
                        }
                        return max + 1;
            }
}         
