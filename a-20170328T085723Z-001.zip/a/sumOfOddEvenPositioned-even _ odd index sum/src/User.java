
public class User {
    public static int evenOddSum(int a) {
        int rem, count = 0, esum = 0, osum = 0;
        while (a != 0) {
                    rem = a % 10;
                    if (count % 2 == 0) {
                                esum = esum + rem;
                    } else {
                                osum = osum + rem;
                    }
                    count++;
                    a = a / 10;
        }
        if (esum == osum) {
                    return 1;
        } else {
                    return -1;
        }
}
}



