import java.util.Scanner;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int n;
Scanner sc=new Scanner(System.in);
n=sc.nextInt();
int res=User.evenOddSum(n);
if(res==1)
	System.out.println("yes");
else
	System.out.println("no");
	}

}
