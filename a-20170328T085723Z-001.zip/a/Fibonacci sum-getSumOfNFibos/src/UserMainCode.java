import java.util.ArrayList;
import java.util.Iterator;




public class UserMainCode {
            public static int getSumOfNFibos(int n) {
                        int first = 0, second = 1, next = 0, sum = 0;
                        ArrayList<Integer> list = new ArrayList<Integer>();
                        for (int i = 0; i < n; i++) {
                                    if (i == 0) {
                                                next = first;
                                    }
                                    if (i == 1) {
                                                next = second;
                                    }
                                    if (i > 1) {
                                                next = second + first;
                                                first = second;
                                                second = next;
                                    }
                                    list.add(next);
                        }
                        Iterator<Integer> iterator = list.iterator();
                        while (iterator.hasNext()) {
                                    Integer integer = iterator.next();
                                    sum = sum + integer;
                        }
                        return sum;
            }
}

