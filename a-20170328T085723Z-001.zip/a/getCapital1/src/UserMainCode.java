import java.util.HashMap;
import java.util.Map;


public class UserMainCode
{
    public static String getCapital(HashMap<String, String> hm, String s1)
    {
        String res = "";
        for (Map.Entry e : hm.entrySet()) 
        {
                    if (e.getKey().equals(s1)) 
                    {
                                res = (e.getValue() + "$" + e.getKey());
                                break;
                    }
        }
        return res;
}


}
