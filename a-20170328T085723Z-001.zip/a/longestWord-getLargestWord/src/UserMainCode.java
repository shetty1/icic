
public class UserMainCode {
            public static String longestWord(String s1) {
                        int max = 0;
                        String output = "";
                        String s[] = s1.split(" ");
                        for (int i = 0; i < s.length; i++) {
                                    if (s[i].length() > max) {
                                                max = s[i].length();
                                                output = s[i];
                                    }
                        }
                        return output;
            }
}
