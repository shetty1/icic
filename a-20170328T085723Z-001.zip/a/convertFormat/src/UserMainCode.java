public class UserMainCode {
            public static String getValues(String s) {
                        String st[] = s.split("-");
                        String s1 = st[0];
                        String s2 = st[1];
                        String s3 = st[2];
                        StringBuffer sb = new StringBuffer();
                        sb.append(s1.substring(0,s1.length()-1)).append('-');
                        sb.append(s1.charAt(s1.length()-1)).append(s2.charAt(0)).append('-');
                        sb.append(s2.substring(1, s2.length())).append(s3.charAt(0)).append('-');
                        sb.append(s3.substring(1, s3.length()));
                        return sb.toString();
            }
}