
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class Main {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

BufferedReader br=new BufferedReader (new InputStreamReader (System.in));
String s=br.readLine();
String s1=UserMainCode.getValues(s);
System.out.println(s1);

	}

}
