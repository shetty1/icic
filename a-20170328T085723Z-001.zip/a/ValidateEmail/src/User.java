
public class User {
	public static boolean ValidateEmail(String email) {
		boolean b = false;
		if (email.matches("[a-zA-Z0-9]{3,}(@)[a-zA-Z]{5,}(.)(com)"))
		b = true;
		return b;
		}
}
