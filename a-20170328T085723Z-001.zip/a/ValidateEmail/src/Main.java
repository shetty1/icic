import java.util.Scanner;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		String email = sc.next();
		System.out.println(User.ValidateEmail(email));
	}

}
