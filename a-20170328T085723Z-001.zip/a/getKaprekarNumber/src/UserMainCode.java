
public class UserMainCode
{
	public static int getKaprekarNumber(int a) 
	{
        int x = 0, y = 0, z = 0;
        int b = a * a;
        String c = String.valueOf(b);
        int d = c.length();
        if (d == 2) {
                    x = b % 10;
                    y = b / 10;
                    z = x + y;
        } else if (d == 4) {
                    x = b % 100;
                    y = b / 100;
                    z = x + y;
        }
        if (z == a) {
                    return 1;
        } else {
                    return -1;
        }
}


}
