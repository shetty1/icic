import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;


public class Main {

	public static void main(String[] args) throws NumberFormatException, IOException {
		// TODO Auto-generated method stub
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
		UserMainCode u=new UserMainCode();
		int year=Integer.parseInt(br.readLine());
		int month=Integer.parseInt(br.readLine());
		int res=u.getNumberOfDays(year,month);
		System.out.println(res);
		
	}

}
