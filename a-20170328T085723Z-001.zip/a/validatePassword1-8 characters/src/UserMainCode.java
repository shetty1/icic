public class UserMainCode {
            public static String validatePassword(String s) {
                        String res = null;
                        if (s.matches("((?=.*[0-9])(?=.*[a-zA-Z])(?=.*[@#$!]).{8,})")) {
                                    res = "Valid";
                        } else {
                                    res = "Invalid";
                        }
                        return res;
}
}
