import java.util.Scanner;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String s;
Scanner sc=new Scanner(System.in);
s=sc.nextLine();
String sa=UserMainCode.validatePassword(s);
if(sa=="Valid")
	System.out.println("valid");
else
	System.out.println("invalid");
	}

}
