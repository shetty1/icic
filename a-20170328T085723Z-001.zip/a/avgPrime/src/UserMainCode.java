public class UserMainCode {
            public static int avgPrime(int a[]) {
                        int sum = 0, c = 0, j;
                        for (int i = 2; i < a.length; i++) {
                                    for (j = 2; j < i; j++) {
                                                if (i % j == 0) {
                                                            c++;
                                                }
                                    }
                                    if (c == 0) {
                                                sum = sum + a[i];
                                    }
                        }
                        int avg = sum / 2;
                        return avg;
            }
}