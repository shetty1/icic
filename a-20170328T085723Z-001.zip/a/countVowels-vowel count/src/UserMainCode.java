public class UserMainCode
{
            public static int countVowels(String s1)
            {
                        String s2 = s1.replaceAll("[aeiouAEIOU]", "");
                        int res = s1.length()-s2.length();
                        return res;
            }
}