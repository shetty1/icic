
public class UserMainCode {
            public static int sumPowerElements(int a[]) {
                        int sum = 0;
                        for (int i = 0; i < a.length; i++) {
                                    sum = (int) (sum + Math.pow(a[i], i));
                        }
                        return sum;
            }
}
