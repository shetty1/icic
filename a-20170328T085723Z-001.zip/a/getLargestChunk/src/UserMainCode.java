import java.util.StringTokenizer;

public class UserMainCode {
            public static int getLargestChunk(String s1) {
                        StringTokenizer st = new StringTokenizer(s1, "");
                        int max = 0;
                        while (st.hasMoreTokens()) {
                                    String s = st.nextToken();
                                    StringBuffer sb = new StringBuffer(s);
                                    for (int i = 0; i < sb.length(); i++) {
                                                int count = 0;
                                                for (int j = i + 1; j < sb.length(); j++) {
                                                            if (sb.charAt(i) == sb.charAt(j)) {
                                                                        count++;
                                                            } else {
                                                                        break;
                                                            }
                                                }
                                                if (count > max) {
                                                            max = count + 1;
                                                }
                                    }
                        }
                        if (max == 0) {
                                    return -1;
                        } else {
                                    return max;
                        }
            }
}
