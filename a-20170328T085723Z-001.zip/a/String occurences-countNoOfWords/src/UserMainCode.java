
public class UserMainCode
{
            public static int countNoOfWords(String s1, String s2)
            {
                        int count=0;
                        String []s3 = s1.split(" ");
                        String []s4 = s2.split(" ");
                        for (int i = 0; i < s3.length; i++)
                        {
                                    if(s4[1].equals(s3[i]))
                                    {
                                                count++;
                                    }
                        }
                        return count;
            }
}

