
public class UserMainCode {
    public static int countSquential(String s1) {
        int c = 0, n = 0;
        for (int i = 0; i < s1.length() - 1; i++) {
                    if (s1.charAt(i) == s1.charAt(i + 1))
                                n++;
                    else
                                n = 0;
                    if (n == 2)
                                c++;
        }
        return c;
}

}
