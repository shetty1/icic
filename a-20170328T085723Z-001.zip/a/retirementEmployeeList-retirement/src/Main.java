import java.util.*;


public class Main 
{

	public static void main(String[] args) 
	{
		Scanner s = new Scanner(System.in);
		int n = s.nextInt();
		LinkedHashMap<String,String> hm = new LinkedHashMap<String,String>();
		for (int i = 0; i < n; i++)
		hm.put(s.next(), s.next());
		System.out.println(UserMainCode.retirementEmployeeList(hm));
		}

	}


