import java.text.SimpleDateFormat;
import java.util.*;


public class UserMainCode 
{
    public static ArrayList<String> retirementEmployeeList(HashMap<String, String> hm)
    {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        ArrayList<String> al = new ArrayList<String>();
        sdf.setLenient(false);
        String s = "01/01/2014";
        try
        {
                    Date d = new Date();
                    d=sdf.parse(s);
                    Calendar cal = Calendar.getInstance();
                    cal.setTime(d);
                    cal.add(Calendar.YEAR, -60);
                    Iterator<String> itr = hm.keySet().iterator();
                    while(itr.hasNext())
                    {
                                String a = itr.next();
                                String s1 = hm.get(a);
                                Date d2 = new Date();
                                d2=sdf.parse(s1);
                                Calendar cal2 = Calendar.getInstance();
                                cal2.setTime(d2);
                                if(cal2.before(cal))
                                {
                                            al.add(a);
                                }
                    }
        }
        catch (Exception e) 
        {
                    e.printStackTrace();
        }
        Collections.sort(al);
        return al;


}
}
