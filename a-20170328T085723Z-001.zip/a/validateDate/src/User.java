
public class User {
    public static int validateDate(String s)
    {
                int result=-1;
                if(s.matches("[0-9]{2}[.]{1}[0-9]{2}[.]{1}[0-9]{4}"))
                {
                            result=1;
                }
                else if(s.matches("[0-9]{2}[/]{1}[0-9]{2}[/]{1}[0-9]{4}"))
                {
                            result=1;
                }
                else if(s.matches("[0-9]{2}[-]{1}[0-9]{2}[-]{1}[0-9]{4}"))
                {
                            result=1;
                }
                return result;
    }
}


