
public class UserMainCode 
{
	public static int validateStrings(String s1) {
        if (s1.matches("(CTS)[-]{1}[0-9]{3}")) {
                    return 1;
        } else {
                    return -1;
        }
}

}
