import java.util.Arrays;
import java.util.LinkedHashSet;


public class User {
	public static String[] orderElements(String[] s) {

		LinkedHashSet<String> lhs=new LinkedHashSet<String>();
		
		for(int i=0;i<s.length;i++)
		{
		lhs.add(s[i]);
		}
		String[] a= new String[lhs.size()];
		for(int i=0;i<s.length;i++)
		{
			lhs.toArray(a);
		}
		Arrays.sort(a);
		return a;
	}
}
