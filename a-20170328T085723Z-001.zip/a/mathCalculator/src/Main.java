import java.util.Scanner;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a,b;
char c;
Scanner sc=new Scanner(System.in);
a=sc.nextInt();
b=sc.nextInt();
c=sc.next().charAt(0);
int d=UserMainCode.mathCalculator(a, b, c);
System.out.println(d);
	}

}
