public class UserMainCode {
            public static int mathCalculator(int a, int b, char c) {
                        int res = 0;
                        if (c == '+') {
                                    res = a + b;
                        } else if (c == '-') {
                                    res = a - b;
                        } else if (c == '*') {
                                    res = a * b;
                        } else if (c == '/') {
                                    res = a / b;
                        } else if (c == '%') {
                                    res = a % b;
                        }
                        return res;
            }
}
