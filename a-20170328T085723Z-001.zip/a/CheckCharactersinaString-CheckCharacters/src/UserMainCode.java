
public class UserMainCode {
	public static int checkChar(String s) {
        StringBuffer sb = new StringBuffer(s);
        sb.reverse();
        String s1 = sb.toString();
        if (s.charAt(0) == s1.charAt(0)) {
                    return 1;
        } else {
                    return -1;
        }
}


}
