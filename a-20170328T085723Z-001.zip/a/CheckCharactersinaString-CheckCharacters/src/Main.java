import java.util.Scanner;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String S;
		Scanner sc=new Scanner(System.in);
		S=sc.nextLine();
		int str=UserMainCode.checkChar(S);
		if(str==1)
		System.out.println("Valid");
		else
			System.out.println("Invalid");
		

	}

}
