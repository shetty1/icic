import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map.Entry;


public class Main {

	public static void main(String[] args) throws NumberFormatException, IOException {
		// TODO Auto-generated method stub
BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
int a=Integer.parseInt(br.readLine());
HashMap<String,Double> b = new HashMap<String,Double>();
HashMap<String,String> c = new HashMap<String,String>();
for(int i=0;i<a;i++)
{
	b.put(br.readLine(),Double.parseDouble(br.readLine()));
}

 c=UserMainCode.examResult(b);
 
 for (Entry<String, String> e : c.entrySet()) 
	{
     	System.out.println(e.getKey()+"\n"+e.getValue());
	}
	}

}
