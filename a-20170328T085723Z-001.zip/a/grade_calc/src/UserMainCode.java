import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;


public class UserMainCode {
    public static HashMap<String, String> examResult(Map<String, Double> m1) {
        HashMap<String, String> m2 = new HashMap<String, String>();
        String s1 = new String();

        Double n = 0.0;
        Iterator<String> i = m1.keySet().iterator();
        while (i.hasNext()) {
                    s1 = (String) i.next();
                    n = m1.get(s1);
                    if (n >= 60) {
                                m2.put(s1, "PASS");
                    } else
                                m2.put(s1, "FAIL");
        }
        return m2;
}

    }

