import java.util.LinkedHashMap;


public class UserMainCode {
	public static LinkedHashMap<Integer, Integer> integerFactorial(int[] a) {
        LinkedHashMap<Integer, Integer> hm = new LinkedHashMap<Integer, Integer>();
        for (int i = 0; i < a.length; i++) {
                    int u=1;
                    for (int j = 1; j <= a[i]; j++) {
                                u=u*j;
                                hm.put(a[i], u);
                    }
        }
        return hm;
}

}
