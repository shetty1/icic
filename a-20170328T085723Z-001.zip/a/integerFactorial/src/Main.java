import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n;
		Scanner sc=new Scanner(System.in);
		n=sc.nextInt();
		int []a=new int[n];
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}
		
		//int b[]=UserMainCode.integerFactorial(a);
		HashMap<Integer, Integer> hm=UserMainCode.integerFactorial(a);
		Set<Integer> hs=hm.keySet();
		Iterator<Integer> it=hs.iterator();
		int m=0;
		while(it.hasNext()){
			m=it.next();
			System.out.println(m+":"+hm.get(m));
		}
		
	}

}
