import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;


public class Main {

	public static void main(String[] args) throws NumberFormatException, IOException {
		// TODO Auto-generated method stub
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
		UserMainCode u=new UserMainCode();
		System.out.println("Enter the String\n");
		String s=br.readLine();
		int res=u.numberValidation(s);
		if(res==1)
		System.out.println("Correct");
		else
			System.out.println("Wrong");
		
	}

}
