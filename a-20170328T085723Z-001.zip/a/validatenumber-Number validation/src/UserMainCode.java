public class UserMainCode {
            public static int numberValidation(String s1) {
                        if (s1.matches("[0-9]{3}[-]{1}[0-9]{3}[-]{1}[0-9]{4}")) {
                                    return 1;
                        } else {
                                    return -1;
                        }
            }
}