public class UserMainCode {
            public static String concatString(String[] s1, int n) {
                        StringBuffer res = new StringBuffer();
                        for (int i = 0; i < s1.length; i++)
                                    res.append(s1[i]).append(",");
                        res.deleteCharAt(res.length() - 1);
                        return res.toString();
            }
}
