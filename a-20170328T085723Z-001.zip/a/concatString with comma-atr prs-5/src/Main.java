import java.util.Scanner;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			int n;
					Scanner sc=new Scanner(System.in);
					n=sc.nextInt();
					String [] s1=new String[n];
					for(int i=0;i<s1.length;i++)
					{
						s1[i]=sc.next();
					} 
String sa=UserMainCode.concatString(s1, n);
System.out.println(sa);
	}

}
