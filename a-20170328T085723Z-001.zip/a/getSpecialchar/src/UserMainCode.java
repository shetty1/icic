public class UserMainCode
{
            public static String getSpecialChar(String s1)
            {
                        String s2 = s1.replaceAll("[a-zA-Z \\s]","");
                        //s2.replaceAll(" +", "");
                        return s2;
            }
}