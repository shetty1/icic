
public class UserMainCode 
{
    public static int addPrimeIndex(int a[],int n) 
    {
        int sum = 0, c = 0, j,temp=0;
        
        for (int i = 2; i < n; i++)
        {
        	c=0;
        	for (j = 1; j < i; j++)
        		{
                 if (i % j == 0)
                  {
                     c++;
                  }
        		}
        	if (c == 1) 
        	{
        		temp++; 
        		sum = sum + a[i];
        	}
        }
        int avg = sum / temp;
        return avg;
    }
}
