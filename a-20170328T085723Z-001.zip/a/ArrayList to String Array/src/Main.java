import java.util.ArrayList;
import java.util.Scanner;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
        ArrayList<String> list = new ArrayList<String>();
        int n = sc.nextInt();
        sc.nextLine();
        for (int i = 0; i < n; i++) {
                    String s = sc.nextLine();
                    list.add(s);
        }
        String[] str = UserMainCode.convertToString(list);
        for (int i = 0; i < str.length; i++)
                    System.out.println(str[i]);
}


	}


