import java.util.ArrayList;


public class UserMainCode {
	public static String[] convertToString(ArrayList<String> list) {
        java.util.Collections.sort(list);
        String s[] = new String[list.size()];
        return list.toArray(s);


}
}

