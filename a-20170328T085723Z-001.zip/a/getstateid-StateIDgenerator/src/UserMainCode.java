import java.util.HashMap;
import java.util.LinkedHashMap;


public class UserMainCode {
	public static HashMap<String, String> getID(String[] s1) {
        LinkedHashMap<String, String> hm = new LinkedHashMap<String, String>();
        for (int i = 0; i < s1.length; i++) {
                    hm.put(s1[i].substring(0, 3).toUpperCase(), s1[i]);
        }
        return hm;
}


}
