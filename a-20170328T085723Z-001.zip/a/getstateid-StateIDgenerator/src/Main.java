import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;




public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n;
		
		Scanner sc=new Scanner(System.in);
		n=sc.nextInt();
		sc.nextLine();
		String []s1=new String[n];
		for(int i=0;i<n;i++){
			s1[i]=sc.nextLine();
		}
		HashMap<String, String> hm=UserMainCode.getID(s1);
		Set<String> hs=hm.keySet();
		Iterator<String> it=hs.iterator();
		String m=null;
		while(it.hasNext()){
			m=it.next();
			System.out.println(m+":"+hm.get(m)); 

	}

}
}

