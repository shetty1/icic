import java.util.HashMap;
import java.util.Scanner;


public class Main {

	public static void main(String[] args) 
	{
		Scanner s = new Scanner(System.in);
		int n = s.nextInt();
		HashMap<Integer, String> hm1 = new HashMap<Integer, String>();
		for (int i = 0; i < n; i++)
		hm1.put(s.nextInt(), s.next()); 
		int res=UserMainCode.sizeOfResultandHashMap(hm1);
		System.out.println(res);
	}

}
