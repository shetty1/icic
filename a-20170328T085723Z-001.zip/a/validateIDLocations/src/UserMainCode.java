
public class UserMainCode 
{
    public static String validateIDLocation(String s1, String s2) {
        String res = null;
        String[] s3 = s1.split("-");
        String id = s3[0];
        String loc = s3[1];
        String xxx = s3[2];
        if (loc.matches(s2.substring(0, 3)) && xxx.length() == 4
                                && id.matches("CTS")) {
                    res = "Valid";
        } else {
                    res = "Invalid";
        }
        return res;
    }
}
