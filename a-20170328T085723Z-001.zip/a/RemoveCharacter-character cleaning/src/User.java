
	public class User{
		 
        public static String removeCharacter(String s1, char ch) {
                    StringBuffer sb = new StringBuffer(s1);
                    for (int i = 0; i < sb.length(); i++) {
                                if (ch == sb.charAt(i)) {
                                            sb.deleteCharAt(i);
                                            i--;
                                }
                    }
                    return sb.toString();
        }
}
