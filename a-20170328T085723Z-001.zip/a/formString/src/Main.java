import java.util.Scanner;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int n=sc.nextInt();
		String[] a=new String[n];
		for(int i=0;i<n;i++)
			a[i]=sc.next();
		int s=sc.nextInt();
		System.out.println(User.formString(a,s));
	}

}
