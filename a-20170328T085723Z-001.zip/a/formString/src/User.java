
public class User {
	public static String formString(String s[],int n) {
		StringBuffer sb=new StringBuffer();
		for(int i=0;i<s.length;i++)
		{
			String st=s[i];
			if(st.length()>=n)
			{
				sb.append(st.charAt(n-1));
			}
			else
				sb.append("$");
		}
	return sb.toString();
	}
}
