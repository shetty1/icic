import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

public class User {
	public static String addTime(String s1, String s2) throws ParseException {
		// adding two times
		SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
		sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
		Date d1 = sdf.parse(s1);
		Date d2 = sdf.parse(s2);
		long time = d1.getTime() + d2.getTime();
		String s = sdf.format(new Date(time));
		// to calculate the day
		Calendar c = Calendar.getInstance();
		c.setTime(sdf.parse(s));
		int day = c.get(Calendar.DAY_OF_MONTH);
		if (day > 1)
		day = day - 1;
		String op = day + ":" + s;
		return op;
		}
}
