
public class User {
            public static int ipValidator(String s1) {
                        int flag = 0;
                        String[] st = s1.split("\\.");
                        for (int i = 0; i < st.length; i++) {
                                    String s2 = st[i];
                                    int n = Integer.parseInt(s2);
                                    if (n > 0 && n <= 255) {
                                                flag++;
                                    }
                        }
                        if (flag == 4) {
 
                                    return 1;
                        } else {
                                    return 2;
                        }
            }
}
