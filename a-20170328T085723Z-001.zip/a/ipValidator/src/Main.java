import java.util.Scanner;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s;
		Scanner sc=new Scanner(System.in);
		s=sc.next();
		int res=User.ipValidator(s);
		if(res==1)
			System.out.println("valid");
		else
			System.out.println("invalid");
	}

}
