import java.util.Scanner;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String s1;
Scanner sc=new Scanner(System.in);
s1=sc.nextLine();
UserMainCode ss=new UserMainCode();
String sa=UserMainCode.properCase(s1);
System.out.println(sa);
	}

}