public class UserMainCode {
 
            public static String properCase(String s1) {
                        StringBuffer sb = new StringBuffer();
                        String[] strArr = s1.split(" ");
                for (String str : strArr) {
                    char[] stringArray = str.trim().toCharArray();
                    stringArray[0] = Character.toUpperCase(stringArray[0]);
                    str = new String(stringArray);
                    sb.append(str).append(" ");
                }
                        return sb.toString().trim();
            }
}

            
        
