
public class UserMainCode {
	public static int maxDiff(int[] a) {
        int max = 0, n1 = 0;
        int[] diff = new int[a.length - 1];
        for (int i = 0; i < a.length - 1; i++) {
                    diff[i] = (int) (a[i] - a[i + 1]);
                    if (diff[i] > 0) {
                                if (diff[i] > max) {
                                            max = diff[i];
                                            n1 = i;

                                }
                    } else {
                                if (Math.abs(diff[i]) > max) {
                                	max = diff[i];
                                    n1 = i + 1;
                        }
            }
}
return n1;

                                }


}
