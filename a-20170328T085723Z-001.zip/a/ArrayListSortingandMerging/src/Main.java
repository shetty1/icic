import java.util.ArrayList;
import java.util.Scanner;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
        int a = 5;
        ArrayList<Integer> al1 = new ArrayList<Integer>();
        ArrayList<Integer> al2 = new ArrayList<Integer>();
        for (int i = 0; i < a; i++) {
                    al1.add(sc.nextInt());
        }
        for (int i = 0; i < a; i++) {
        	al2.add(sc.nextInt());
        }
        al1.addAll(al2);
        ArrayList<Integer> s = UserMainCode.sortMergedArrayList(al1, al2);
        Integer t[] = new Integer[s.size()];
        s.toArray(t);
        for (int i = 0; i < t.length; i++) {
                    System.out.println(t[i]);
        }
}

        }


	


