public class UserMainCode {
            public static String getString(String s) {
                        StringBuffer sb = new StringBuffer();
                        // String output;
                        if (s.charAt(0) == 'j') {
                                    if (s.charAt(1) == 'b') {
                                                sb.append(s);
                                    } else {
                                                sb.append(s.charAt(0)).append(s.substring(2));
                                    }
                        } else if (s.charAt(1) == 'b') {
                                    sb.append(s.charAt(0)).append(s.substring(2));
                        } else {
                                    sb.append(s.substring(2));
                        }
                        return sb.toString();
            }
}