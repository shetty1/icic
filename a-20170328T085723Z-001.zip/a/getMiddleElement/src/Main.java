import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class Main {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
//String s1;
BufferedReader br=new BufferedReader (new InputStreamReader (System.in));
int s=Integer.parseInt(br.readLine());
int [] a=new int[s];

for(int i=0;i<s;i++)
{
	a[i]=Integer.parseInt(br.readLine());
}
int b=UserMainCode.getMiddleElement(a);
System.out.println(b);

	}

}