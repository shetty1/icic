public class UserMainCode
{
            public static int getMiddleElement(int a[])
            {
                        int count=a.length;
                        return a[count/2];
            }
}