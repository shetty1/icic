import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;


public class UserMainCode {
	public static int date(String s,String s1){
		int res=0;
		SimpleDateFormat adf=new SimpleDateFormat("yyyy-MM-dd");
		adf.setLenient(false); 
try
		{ 
Date d=adf.parse(s);
			Date d1=adf.parse(s1);
			Calendar cal=Calendar.getInstance();
			cal.setTime(d);
			int m1=cal.get(Calendar.MONTH)+1;
			int y1=cal.get(Calendar.YEAR);
			cal.setTime(d1);
			int m2=cal.get(Calendar.MONTH)+1;
			int y2=cal.get(Calendar.YEAR); 
if(y1!=y2)
			{
			if(y2>y1)
				y2-=1;
			else
				y1-=1;
			
			if(m1<m2)
				m1=12-m1;
			else
				m2=12-m2;
			
			//System.out.println(m1+" "+m2+" "+y1+" "+y2);
			 res=Math.abs(y1-y2)*12+(m2+m1);
			} 
	else
			{
				//System.out.println(m1+" "+m2+" "+y1+" "+y2);
				res=Math.abs(m1-m2);
			}
		}
	catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			//System.out.println(res);
			return res;
		}
	}
}
