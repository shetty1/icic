import java.util.Scanner;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1,s2;
		Scanner sc=new Scanner(System.in);
		s1=sc.next();
		s2=sc.next();
		int x=UserMainCode.regularExpIII(s1, s2);
		System.out.println(x);
		

	}

}
