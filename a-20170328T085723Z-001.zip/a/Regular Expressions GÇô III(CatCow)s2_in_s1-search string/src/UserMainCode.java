
public class UserMainCode {
	public static int regularExpIII(String s1, String s2) {
		int lastIndex = 0;
		int count = 0;
		while(lastIndex != -1){
		    lastIndex = s1.indexOf(s2,lastIndex);
		    if(lastIndex != -1){
		        count ++;
		        lastIndex += s2.length();
		    }
		}
		return count;
	}

}
