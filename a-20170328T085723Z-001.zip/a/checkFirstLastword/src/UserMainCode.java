
public class UserMainCode 
{
    public static int check(String s1) 
    {
        int res = 0;
        String s[] = s1.split(" ");
        if (s[0].equals(s[s.length - 1])) 
        {
                    res = s[0].length();
        } else 
        {
                    res = (s[0].length() + s[s.length - 1].length());
        }
        return res;
}


}
