import java.util.*;


public class Main 
{

	public static void main(String[] args) 
	{
		Scanner s = new Scanner(System.in);
		String ss = s.nextLine();
		System.out.println(UserMainCode.check(ss));

	}

}
