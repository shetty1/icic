import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.StringTokenizer;
public class User {
public static String findFruitName(String s1,int n) {
	StringTokenizer st=new StringTokenizer(s1,",");
	int c=0,i=0;
	String ss=null;
	String[] s=new String[st.countTokens()];
	while(st.hasMoreTokens())
	{
		s[i]=st.nextToken();
		i++;
	}
	if(i>n)
	{
	 ss=s[n-1];
	}
	else
	{
		ss=s[i-1];
	}
	
	return ss;
}
}
 
