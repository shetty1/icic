import java.sql.Date;
import java.util.Calendar;


public class User {
    public static boolean validateExp(String s, String s1) {
        int y1 = Integer.parseInt(s);
        Date d = new Date(y1);
        Calendar cal = Calendar.getInstance();
        int y2 = cal.get(Calendar.YEAR);
        int y = Math.abs(y1-y2);
        int e = Integer.parseInt(s1);
        if(y>=e)
                    return true;
        else
        return false;
}
}
