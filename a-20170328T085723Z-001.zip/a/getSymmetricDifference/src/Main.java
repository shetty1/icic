import java.util.Scanner;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);

		int n1=sc.nextInt();
		int[] a=new int[n1];
		for(int i=0;i<n1;i++)
		a[i]=sc.nextInt();
		int n2=sc.nextInt();
		int[] b= new int[n2];
		for(int i=0;i<n2;i++)
		b[i]=sc.nextInt();
		int[] res=User.display(a,b,n1,n2);
		for(int i=0;i<res.length;i++)
		System.out.println(res[i]);
	}

}
