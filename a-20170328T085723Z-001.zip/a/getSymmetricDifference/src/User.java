import java.util.ArrayList;
import java.util.TreeSet;


public class User {
	public static int[] display(int a[],int b[],int n1,int n2)
	{
	TreeSet<Integer> ts1=new TreeSet<Integer>();
	TreeSet<Integer> ts2=new TreeSet<Integer>();
	TreeSet<Integer> ts3=new TreeSet<Integer>();
	ArrayList<Integer> aa=new ArrayList<Integer>();
	for(int i=0;i<a.length;i++)
	ts1.add(a[i]);
	for(int i=0;i<b.length;i++)
	ts2.add(b[i]);
	ts1.addAll(ts2);
	for(int i=0;i<n1;i++)
	{
	for(int j=0;j<n2;j++)
	{
	if(a[i]==b[j])
		ts3.add(a[i]);
	}
	}
	ts1.removeAll(ts3);
	aa.addAll(ts1);
	int res[]=new int[aa.size()];
	for(int i=0;i<res.length;i++)
	res[i]=aa.get(i);
	return res;
	}
}
