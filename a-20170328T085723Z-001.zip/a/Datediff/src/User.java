import java.text.SimpleDateFormat;
import java.util.Date;


public class User {
 
            public static int Datediff(String s1, String s2) {
                        int n = 0;
                        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                        try {
                                    Date d = sdf.parse(s1);
                                    Date d1 = sdf.parse(s2);
 
                                    double diff = Math.abs(d.getTime() - d1.getTime());
                                    double factor = 1000 * 3600 * 24;
                                    int difference = (int) (diff / factor);
                                    n = difference;
 
                        } catch (Exception e) {
                                    System.out.println("Enter date in correct format");
                        }
                        return n;
            }
}
