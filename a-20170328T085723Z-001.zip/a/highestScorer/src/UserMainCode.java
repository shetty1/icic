import java.util.ArrayList;
import java.util.StringTokenizer;


public class UserMainCode 
{
	public static String highestScorer(ArrayList<String> a) 
	{
		String ss=null,name=null,Name=null;
		int m1=0,m2=0,m3=0,sum=0,max=0;
		for(int i=0;i<a.size();i++)
		{
			ss=a.get(i);
			StringTokenizer st=new StringTokenizer(ss,"-");
			while(st.hasMoreTokens())
			{
				name=st.nextToken();
				m1=Integer.parseInt(st.nextToken());
				m2=Integer.parseInt(st.nextToken());
				m3=Integer.parseInt(st.nextToken());
				sum=m1+m2+m3;
				if(max<sum)
				{
					max=sum;
					Name=name;
				}
			}
		}
		return Name;
		}

}
