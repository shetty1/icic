
public class User {
            public static int getSumofSq(int a) {
                        int rem, num = 1, sum = 0;
                        while (a != 0) {
                                    rem = a % 10;
                                    num = rem * rem;
                                    sum += num;
                                    a /= 10;
                        }
                        return sum;
            }
}
