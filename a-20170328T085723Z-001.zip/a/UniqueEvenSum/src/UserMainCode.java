import java.util.ArrayList;


public class UserMainCode {
	public static int uniqueEvenSum(int a[]) {
        int sum = 0, count = 0;
        ArrayList<Integer> al = new ArrayList<Integer>();
        al.add(a[0]);
        for (int i = 1; i < a.length; i++) {
                    if (!al.contains(a[i])) {
                                al.add(a[i]);
                    }
        }
        for (int j = 0; j < al.size(); j++) {
                    if (al.get(j) % 2 == 0) {
                                sum = sum + al.get(j);
                    } else {
                                count++;
                    }
        }
        if (count == al.size())
                    return -1;
        else
            return sum;

        


}
}