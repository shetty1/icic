import java.util.HashMap;
import java.util.Scanner;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		int n = s.nextInt();
		HashMap<Integer, Float> hm = new HashMap<Integer, Float>();
		for (int i = 0; i < n; i++)
		{
			hm.put(s.nextInt(),s.nextFloat());
		}
		String ss=UserMainCode.avgElementHashMap(hm);
		System.out.println(ss);

		}


	}


