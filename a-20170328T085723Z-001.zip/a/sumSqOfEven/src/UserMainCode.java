
public class UserMainCode {
    public static int sumSqOfEven(int a) {
        int rem, sum = 0, square;
        while (a != 0) {
                    rem = a % 10;
                    if (rem % 2 == 0) {
                                square = rem * rem;
                                sum = sum + square;
                    }
                    a = a / 10;
        }
        return sum;
}


}
