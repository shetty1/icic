import java.util.Scanner;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a;
		Scanner sc=new Scanner(System.in);
		a=sc.nextInt();
		UserMainCode obj=new UserMainCode();
		int z=obj.sumSqOfEven(a);
		System.out.println(z);

	}

}
