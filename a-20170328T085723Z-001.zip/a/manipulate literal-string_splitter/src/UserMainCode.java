
public class UserMainCode {
	public static String[] stringSplitter(String s1, char c) {
        String[] op=s1.split(String.valueOf(c));
        for (int i = 0; i < op.length; i++) {
                    op[i]=op[i].toLowerCase();
                    StringBuffer a=new StringBuffer(op[i]);
                    a.reverse();
                    op[i]=a.toString();
        }
                    return op;
        }

}
