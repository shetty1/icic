import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class Main {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader b=new BufferedReader(new InputStreamReader(System.in));
		String s1=b.readLine();
		char c=b.readLine().charAt(0);
		String s2=UserMainCode.reshape(s1, c);
		System.out.println(s2);
	}

}
