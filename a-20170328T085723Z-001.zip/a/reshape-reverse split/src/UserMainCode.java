
public class UserMainCode {
            public static String reshape(String s1, char c) {
                        StringBuffer buffer = new StringBuffer(s1);
                        StringBuffer buffer2 = new StringBuffer();
                        buffer.reverse();
                        for (int i = 0; i < buffer.length(); i++) {
                                    buffer2.append(buffer.charAt(i)).append(c);
 
                        }
                        buffer2.deleteCharAt(buffer2.length() - 1);
                        return buffer2.toString();
            }
}
