import java.util.HashMap;
import java.util.Iterator;


public class UserMainCode {
    public static Float priceCalculator(HashMap<String, String> hm, String[] s1) {
        Float f = (float) 0;
        Iterator<String> it = hm.keySet().iterator();
        while (it.hasNext()) {
                    String s = (String) it.next();
                    Float f1 = Float.parseFloat(hm.get(s));
                    for (int i = 0; i < s1.length; i++) {
                                if (s1[i].equals(s))
                                            f += f1;
                    }
        }
        return f;
}
}


