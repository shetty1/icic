import java.util.HashMap;
import java.util.Scanner;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
			HashMap<String, String> hm=new HashMap<String,String>();
					Scanner in=new Scanner(System.in);
					int m,n;
					m=in.nextInt();in.nextLine();
					for(int i=0;i<m;i++)
						hm.put(in.nextLine(),in.nextLine());
					n=in.nextInt();in.nextLine();
					String[] products=new String[n];
					for(int i=0;i<n;i++){ 
			
			products[i]=in.nextLine();
					}
					float f=UserMainCode.priceCalculator(hm, products);
					System.out.println(f); 
			
	}

}
