import java.util.StringTokenizer;


public class User {
	public static boolean scanStarNeighbors(String s) {
		StringTokenizer st=new StringTokenizer(s,"*");
		boolean b=false;
		while(st.hasMoreTokens())
		{
			String s1=st.nextToken();
			String s2=st.nextToken();
			if(s1.charAt(s1.length()-1)==s2.charAt(0))
			{
				b=true;
			}
		}
		return b;
	}
}
