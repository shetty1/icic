public class UserMainCode {
 
            public static int findDistance(int x1, int x2, int y1, int y2)
            {                     
                        int result = 0;
                        result= (int)Math.round(Math.sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2)));
                        return result;
            }
}