import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
public class Main {

	public static void main(String[] args) throws NumberFormatException, IOException {
		// TODO Auto-generated method stub
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
		UserMainCode u=new UserMainCode();
		int x1=Integer.parseInt(br.readLine());
		int x2=Integer.parseInt(br.readLine());
		int y1=Integer.parseInt(br.readLine());
		int y2=Integer.parseInt(br.readLine());
		int res=UserMainCode.findDistance(x1, x2, y1, y2);
		
		System.out.println(res);
		
	}

}