
public class User {
	public static int getSubstring (String s1,String s2) {
		int count=0;
		int n=s1.length()-(s2.length()-1);
		for(int i=0;i<n;i++)
		{
			String s3=s1.substring(i,i+(s2.length()));
			if(s2.equals(s3))
			count++;
		}
		return count;
	}
}
