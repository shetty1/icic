import java.util.Scanner;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		String s1=sc.next();
		String s2=sc.next();
		System.out.println(User.getSubstring(s1, s2));
	}

}
