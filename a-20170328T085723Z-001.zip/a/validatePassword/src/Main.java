import java.util.Scanner;


public class Main {

	public static void main(String[] args) 
	{
	 Scanner sc=new Scanner(System.in);
	 String s1=sc.next();
	 int res=UserMainCode.validatePassword(s1);
	 if(res==-1)
		 System.out.println("Invalid");
	 else
		 System.out.println("Valid");

	}

}
