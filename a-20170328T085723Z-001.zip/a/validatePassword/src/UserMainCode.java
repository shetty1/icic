
public class UserMainCode 
{
	public static int validatePassword(String s1) 
	{
        if(!Character.toString(s1.charAt(0)).matches("[0-9]") ||
        		!Character.toString(s1.charAt(0)).matches("[@_$]") )
        {
        	if (s1.matches("(?=.*[0-9])(?=.*[a-zA-Z])(?=.*[@_$]).{8,}"))
        
			 return 1;
		 else
			 return -1;
        }
		else
			return -1;
	}

}
