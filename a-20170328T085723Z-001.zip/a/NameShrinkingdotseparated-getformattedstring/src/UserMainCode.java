
public class UserMainCode {
	public static String nameShrinking(String s1) {
        StringBuffer sb = new StringBuffer();
        String s[] = s1.split(" ");
        sb.append(s[s.length - 1]).append(" ").append(s[1].charAt(0))
                                .append(".").append(s[0].charAt(0));
        return sb.toString();
}


}
