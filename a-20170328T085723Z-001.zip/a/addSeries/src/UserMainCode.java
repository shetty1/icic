import java.util.*;


public class UserMainCode 
{
    public static int addSeries (int n) 
    {
        ArrayList<Integer> al1 = new ArrayList<Integer>();
        for (int i = 1; i <= n; i++)
                    if (i % 2 != 0)
                        al1.add(i);
        int n1 = al1.get(0);
        for (int i = 1; i < al1.size(); i++)
            if (i % 2 != 0)
                        n1 = n1 + al1.get(i);
            else
                        n1 = n1 - al1.get(i);
return n1;
}

}
