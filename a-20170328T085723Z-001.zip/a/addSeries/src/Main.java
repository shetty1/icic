import java.util.*;


public class Main
{

	public static void main(String[] args) 
	{
		int n;
		Scanner sc=new Scanner(System.in);
		n=sc.nextInt();
		int r=UserMainCode.addSeries(n);
		System.out.println(r);
	}

}
