import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class Main {

	public static void main(String[] args) throws Exception {

BufferedReader br=new BufferedReader (new InputStreamReader (System.in));
int s=Integer.parseInt(br.readLine());
int [] a=new int[s];
int [] b=new int[s];
for(int i=0;i<s;i++)
{
	a[i]=Integer.parseInt(br.readLine());
}
for(int i=0;i<s;i++)
{
	b[i]=Integer.parseInt(br.readLine());
}
int sum=UserMainCode.commonElement(a,b);
System.out.println(sum);

	}

}