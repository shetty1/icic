
public class UserMainCode
{
    public static String concatstring (String s1, String s2)
    {
        String res = "";
        int a1 = s1.length();
        int a2 = s2.length();

        if (a1 == a2) {
                    res = s1.concat(s2);
        } else if (a1 > a2) {
                    res = s1.substring(a1 - a2, a1);
                    res = res.concat(s2);
        } else if (a2 > a1) {
                    res = s2.substring(a2 - a1, a2);
                    res = s1.concat(res);
        }
        return res;
}


}
