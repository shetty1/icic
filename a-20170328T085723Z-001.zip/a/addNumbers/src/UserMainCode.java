
public class UserMainCode 
{
	public static int addNumbers(int n){
		int c=0,sum=0;
		 for (int i = 1; i <= n; i++)         
	     { 		  	  
	        c=0; 	  
	        for(int j=1;j<=i;j++)
		  {
	           if(i%j==0)
			c++;
		  }
		  if (c==2)
			  ;
		  else
			  sum=sum+i;
	     }
		 return sum;
		}

}
