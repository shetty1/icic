
public class User {
	public static boolean checkTripplets  (int a[]) {
            boolean b = false;
            for (int i = 0; i < a.length - 3; i++) {
                        if ((a[i] == a[i + 1]) && (a[i + 1] == a[i + 2])) {
                                    b = true;
                        }
            }
            return b;
        }
}
