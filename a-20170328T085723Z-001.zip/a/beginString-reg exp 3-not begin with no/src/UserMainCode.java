public class UserMainCode {
 
            public static boolean beginString(String s1)
            {
                        boolean b=false;
                        if(s1.matches("[A-Za-z][a-zA-Z]*[0-9]*"))
                        {
                                    b=true;
                        }
                        return b;
            }
}