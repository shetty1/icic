import java.util.*;


public class UserMainCode
{
    public static String getMaxKeyValue(HashMap<Integer, String> hm) 
    {
        int b = 0, max = 0;
        String s1 = new String();
        Iterator<Integer> i = hm.keySet().iterator();
        while (i.hasNext()) 
        {
                    b = i.next();
                    if (b > max)
                    {
                                max = b;
                                s1 = hm.get(b);
                    }
        }
        return s1;
    }

}
