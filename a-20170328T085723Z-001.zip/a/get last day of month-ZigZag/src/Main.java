import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;


public class Main {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
String s1;
BufferedReader br=new BufferedReader(new InputStreamReader(System.in)); 
s1=br.readLine();
UserMainCode u=new UserMainCode();
int sa=u.ZigZag(s1);
System.out.println(sa);
	}

}
