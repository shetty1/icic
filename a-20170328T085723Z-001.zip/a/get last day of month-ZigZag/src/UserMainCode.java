import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class UserMainCode {
 
            public static int ZigZag(String s1) {
                        int n = 0;
                        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
                        Calendar cal = Calendar.getInstance();
                        try {
                                    Date d = (Date) sdf.parse(s1);
                                    cal.setTime(d);
                                    n = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
                        } catch (Exception e) {
                                    e.printStackTrace();
                        }
                        return n;
            }
}
