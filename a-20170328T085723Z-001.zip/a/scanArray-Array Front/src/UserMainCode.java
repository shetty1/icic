public class UserMainCode {
            public static boolean scanArray(int a[]) {
                        if (a[0] == 9 || a[1] == 9 || a[2] == 9 || a[3] == 9) {
                            return true;
                } else {
                            return false;
                }
                        
            }
}
    
