

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;


public class UserMainCode {
    public static int dateValidate(String s1) {
        int res = 0;
        if (s1.matches("[0-9]{2}/[0-9]{2}/[0-9]{4}")) {
                    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                    sdf.setLenient(false);
                    try {
                                Date d = (Date) sdf.parse(s1);
                                res = 1;
                    } catch (ParseException e) {
                                res = -1;
                    }
        }
        return res;


}
}

