import java.util.Scanner;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String S1;
		Scanner sc=new Scanner(System.in);
		S1=sc.nextLine();
		UserMainCode obj=new UserMainCode();
		int str=obj.dateValidate(S1);
		if(str==1)	
		System.out.println("Valid date format");
		else
		System.out.println("Invalid date format");
			


	}

}
