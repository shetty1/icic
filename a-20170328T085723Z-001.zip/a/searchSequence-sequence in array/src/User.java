
public class User {
	public static boolean calculateMedian(int s[]) {
		int[] a={1,2,3};
		int n=s.length-(a.length-1);
		boolean b=false;
		for(int i=0;i<n;i++)
		{
			if(s[i]==a[0] )
			{
				if(s[i+1]==a[1])
				{
					if(s[i+2]==a[2])
					{
						b=true;
						break;
					}
					else
						b=false;
			}
				else 
					b=false;
			}
			else
				b=false;
		}
		return b;
	}
}
