import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class UserMainCode {
            public static int dateValidate(String s1) {
                        int res = 0;
                        if (s1.matches("[0-9]{2}/[0-9]{2}/[0-9]{4}")) {
                                    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                                    sdf.setLenient(false);
                                    try {
                                                Date d = sdf.parse(s1);
                                                res = 1;
                                    } catch (ParseException e) {
                                                res = 0;
                                    }
                        } else if (s1.matches("[0-9]{2}[.]{1}[0-9]{2}[.]{1}[0-9]{4}")) {
                                    SimpleDateFormat sdf1 = new SimpleDateFormat("dd.MM.yyyy");
                                    sdf1.setLenient(false);
                                    try {
                                                Date d1 = sdf1.parse(s1);
                                                res = 1;
                                    } catch (ParseException e) {
                                                res = 0;
                                    }
                        } else if (s1.matches("[0-9]{2}[-]{1}[0-9]{2}[-]{1}[0-9]{4}")) {
                                    SimpleDateFormat sdf2 = new SimpleDateFormat("dd-MM-yyyy");
                                    sdf2.setLenient(false);
                                    try {
                                                Date d2 = sdf2.parse(s1);
                                                res = 1;
                                    } catch (ParseException e) {
                                                res = 0;
                                    }
                        }
                        return res;
            }
}