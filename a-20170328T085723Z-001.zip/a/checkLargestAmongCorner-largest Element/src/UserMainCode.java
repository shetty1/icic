
public class UserMainCode 
{
	public static int checkLargestAmongCorner(int a[])
	{
        int s = a.length;
        System.out.println(s);
        int res = 0;
        int first = a[0]; 
        int mid = a[(s-1)/2];  
        int last = a[s-1];	 
        
        if (first > mid && first > last) 
        {
                    res = first;
        }
        else if (mid > last) 
        {
                    res = mid;
        }
        else 
        {
        	res = last;
        }
      
        return res;
	}

}
