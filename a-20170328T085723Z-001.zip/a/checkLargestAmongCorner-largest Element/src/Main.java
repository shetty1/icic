import java.util.Scanner;


public class Main {

	public static void main(String[] args) 
	{
		
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		if(n<=20)
		{
			int a[]=new int[n];
			for(int i=0;i<n;i++)
			{
			a[i]=sc.nextInt();
			}
			int res=UserMainCode.checkLargestAmongCorner(a);
			System.out.println(res);
		}
	}

}
