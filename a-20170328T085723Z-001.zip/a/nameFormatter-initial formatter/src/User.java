
public class User {
    public static String nameFormatter(String s) {
        StringBuffer sb = new StringBuffer();
        String s1[] = s.split(" ");
        sb.append(s1[1]).append(",").append(s1[0].charAt(0));
        return sb.toString();
}
}
