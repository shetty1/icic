import java.util.*;


public class Main {

	public static void main(String[] args) 
	{
		Scanner s = new Scanner(System.in);
		int n = s.nextInt();
		HashMap<Integer, Integer> hm1 = new HashMap<Integer, Integer>();
		for (int i = 0; i < n; i++)
		hm1.put(s.nextInt(), s.nextInt());
		System.out.println(UserMainCode.getAverageOfOdd(hm1,n));
		}

}
