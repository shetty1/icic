import java.util.*;


public class UserMainCode 
{
	public static int getAverageOfOdd(HashMap<Integer, Integer> hm, int s) 
	{
        int sum = 0, avg = 0, count = 0;
        Iterator<Integer> itr = hm.keySet().iterator();
        {
                    while (itr.hasNext()) 
                    {
                                int j = itr.next();
                                if (j % 2 != 0) 
                                {
                                            sum = sum + hm.get(j);
                                            count++;
                                }
                    }
                    avg = sum / count;
                    return avg;
        }
}


}
