import java.util.ArrayList;
import java.util.Iterator;
public class UserMainCode {
	public static Integer oddDigitSum(String s1[], int size) {
        int sum = 0;
        String s2[] = new String[size];
        for (int i = 0; i < size; i++) {
                    s2[i] = s1[i].replaceAll("[a-zA-Z]", "");
        }
        int s3[] = new int[size];
        for (int i = 0; i < size; i++) {
                    s3[i] = Integer.parseInt(s2[i]);
        }

        ArrayList<Integer> al = new ArrayList<Integer>();
        for (int i = 0; i < s3.length; i++) {
                    al.add(s3[i]);
        }
        Iterator <Integer>itr = al.iterator();
        {
        	while (itr.hasNext()) {
                int x = itr.next();
                int rem;
                while (x != 0) {
                            rem = x % 10;
                            if (rem % 2 != 0) {
                                        sum = sum + rem;
                            }
                            x = x / 10;
                }
    }
    return sum;

        }


}
}
