import java.util.Scanner;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int size;
		Scanner sc=new Scanner(System.in);
		size=sc.nextInt();
		sc.nextLine();
		String [] s1=new String[size];
		for(int i=0;i<size;i++)
		{
			s1[i]=sc.nextLine();
		}
		
		int x=UserMainCode.oddDigitSum(s1, size);
		System.out.println(x);

	}

}
