public class UserMainCode {
            public static int comparelastWord(String s1) {
                        String s2[] = s1.split(" ");
                        if (s2[0].equals(s2[(s2.length) - 1])) {
                                    return s2[0].length();
                        } else {
                                    return (s2[0].length() + s2[(s2.length) - 1].length());
                        }
}
}