
public class User {
	public static int testOrderVowels(String s1) {

		StringBuffer sb = new StringBuffer();
		int res = 0;
		for (int i = 0; i < s1.length(); i++) {
		if (s1.charAt(i) == 'a' || s1.charAt(i) == 'A'
		|| s1.charAt(i) == 'e' || s1.charAt(i) == 'E'
		|| s1.charAt(i) == 'i' || s1.charAt(i) == 'I'
		|| s1.charAt(i) == 'o' || s1.charAt(i) == 'O'
		|| s1.charAt(i) == 'u' || s1.charAt(i) == 'U') {
		sb.append(s1.charAt(i));
		}
		}
		if (sb.toString().equals("aeiou"))
		res = 1;
		else
		res = 0;
		return res;
		}
}
