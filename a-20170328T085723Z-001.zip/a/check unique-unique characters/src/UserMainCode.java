import java.util.Scanner;
public class UserMainCode {
	static String commonChars(String s)
		{
			int flag=0;
			StringBuffer as=new StringBuffer(s);
			for(int i=0;i<as.length();i++)
			{
				flag=0;
				for(int j=i+1;j<as.length();j++)
					if(as.charAt(i)==as.charAt(j))
					{
						flag=1;
						as.deleteCharAt(j);
						j--;
					} 

				if(flag==1)
				{
					as.deleteCharAt(i);
					i--;
				}
			}
			return as.toString();
		}
}
