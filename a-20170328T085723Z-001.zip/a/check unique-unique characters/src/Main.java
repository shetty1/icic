import java.util.Scanner;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in=new Scanner(System.in);
		String a=in.nextLine();
		String b=in.nextLine();
		a=UserMainCode.commonChars(a);
		b=UserMainCode.commonChars(b);
		int i,j,count=0; 

		for(i=0;i<a.length();i++)
		{
			
			for(j=0;j<b.length();j++)
				if(a.charAt(i)==b.charAt(j))
				{
					
					count++;
				}
		}
		
		System.out.println(count);
		in.close();

	}

}
