
public class UserMainCode {
    public static int countVowels(String s1) {
        int count=0;
        s1= s1.replaceAll("[^aeiouAEIOU]", "");
        count=s1.length();
        return count;
}

}
