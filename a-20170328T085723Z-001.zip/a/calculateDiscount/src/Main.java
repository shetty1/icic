import java.text.ParseException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;
import java.util.TreeMap;


public class Main {

	public static void main(String[] args) throws ParseException {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int s=Integer.parseInt(sc.nextLine());
		HashMap<String,String>hm=new HashMap<String,String>();
		HashMap<String,Integer>hm1=new HashMap<String,Integer>();
		for(int i=0;i<s;i++)
		{
		String id=sc.nextLine();
		hm.put(id, sc.nextLine());
		hm1.put(id,Integer.parseInt(sc.nextLine())); 
		}
		TreeMap<String,Integer>tm=new TreeMap<String,Integer>();
		tm=User.calculateDiscount(hm, hm1);
		Iterator<String> it=tm.keySet().iterator();
		while(it.hasNext())
		{
		String n=it.next();
		int fac=tm.get(n);
		System.out.println(n+":"+fac);
	}
	}
}
