import java.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.TreeMap;


public class User {
	public static TreeMap<String,Integer> calculateDiscount(HashMap<String,String>hm,HashMap<String,Integer>hm1) throws ParseException
	{
	TreeMap<String,Integer> tm=new TreeMap<String,Integer>();
	SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
	Iterator<String> itr1=hm.keySet().iterator();
	while(itr1.hasNext())
	{
		try
		{
		String id=itr1.next();
		String dor=hm.get(id);
		int am=hm1.get(id);
		Date d1=(Date) sdf.parse(dor);
		String s1="01-01-2015";
		Date d2=(Date) sdf.parse(s1);
		int y1=d1.getYear();
		int m1=d1.getMonth();
		int day1=d1.getDay();
		int y2=d2.getYear();
		int m2=d2.getMonth();
		int day2=d2.getDay();
		int exp=Math.abs(y1-y2);
		if(m1==m2)
		{
			if(day2>day1)
				exp--;
			}
		if(m2>m1)
			exp--;
		if(am>=20000 && exp>=5)
		{
			int dis=(int) (0.20*am);
			tm.put(id,dis);
		}
		else if(am>=20000 && exp<5)
		{
			int dis=(int) (0.1*am);
			tm.put(id,dis);
		}
		else if(am<20000 && exp>=5)
		{
			int dis=(int) (0.15*am);
			tm.put(id,dis);
		}
		else if(am<20000 && exp<5)
		{
			int dis=(int) (0.05*am);
			tm.put(id,dis);
		}
		}
		catch(Exception e){
			System.out.println(e);
		}	
	}
	return tm;
	}
}
