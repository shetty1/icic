import java.util.Scanner;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String s1;
int s2;
Scanner sc=new Scanner(System.in);
s1=sc.nextLine();
s2=sc.nextInt();
String sa=UserMainCode.repeatingChar(s1,s2);
System.out.println(sa);
	}

}
