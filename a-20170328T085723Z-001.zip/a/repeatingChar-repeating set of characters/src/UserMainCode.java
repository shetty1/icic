public class UserMainCode
{
            public static String repeatingChar(String s1, int s2)
            {
                        int s3 = s1.length();
                        String s4 = s1.substring(s3 - s2);
                        StringBuffer sb = new StringBuffer(s1);
                        for (int i = 0; i < s2; i++)
                        {
                                    sb.append(s4);
                        }
                        return sb.toString();
                       
            }
}
