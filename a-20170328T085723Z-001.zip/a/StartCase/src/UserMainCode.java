
public class UserMainCode {
	public static String startCase(String s1) {
        String[] arr = s1.split(" ");
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < arr.length; i++) {
                    sb.append(Character.toUpperCase(arr[i].charAt(0)))
                                            .append(arr[i].substring(1)).append(" ");
        }
        return sb.toString().trim();
}


}
