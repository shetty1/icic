import java.util.Scanner;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String S1;
		Scanner sc=new Scanner(System.in);
		S1=sc.nextLine();
		UserMainCode obj=new UserMainCode();
		String str=obj.startCase(S1);
		System.out.println(str);


	}

}
